var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-quote/route.js")
R.c("server/chunks/[root-of-the-server]__1bf1fd6b._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__efafb54b._.js")
R.c("server/chunks/_next-internal_server_app_api_send-quote_route_actions_95cc7311.js")
R.m(12158)
module.exports=R.m(12158).exports
