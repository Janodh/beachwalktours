var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-quote/route.js")
R.c("server/chunks/node_modules_12c1c97d._.js")
R.c("server/chunks/[root-of-the-server]__509d98ac._.js")
R.c("server/chunks/_next-internal_server_app_api_send-quote_route_actions_95cc7311.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/send-quote/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/send-quote/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
