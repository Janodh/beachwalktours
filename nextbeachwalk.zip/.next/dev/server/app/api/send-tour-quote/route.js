var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-tour-quote/route.js")
R.c("server/chunks/node_modules_7434f2ad._.js")
R.c("server/chunks/[root-of-the-server]__3a5126d6._.js")
R.c("server/chunks/_next-internal_server_app_api_send-tour-quote_route_actions_4d7914f7.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/send-tour-quote/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/send-tour-quote/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
