module.exports = [
"[project]/.next-internal/server/app/vehicle-rent/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_vehicle-rent_page_actions_1001320f.js.map