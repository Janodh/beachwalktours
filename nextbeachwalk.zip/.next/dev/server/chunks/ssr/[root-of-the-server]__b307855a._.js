module.exports = [
"[project]/src/components/VehicleCarousel.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VehicleCarousel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/index.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/navigation.mjs [app-ssr] (ecmascript) <export default as Navigation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/pagination.mjs [app-ssr] (ecmascript) <export default as Pagination>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$autoplay$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Autoplay$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/autoplay.mjs [app-ssr] (ecmascript) <export default as Autoplay>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VehicleQuoteModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/VehicleQuoteModal.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const items = [
    {
        title: "Toyota Premio",
        image: "/premio.jpg",
        label: "1–3 Pax (with Baggage)"
    },
    {
        title: "Toyota Hiace KDH",
        image: "/kdh.jpg",
        label: "10 Pax (with Baggage)"
    },
    {
        title: "Xiamen Golden Dragon",
        image: "/xiamen.jpg",
        label: "35–50 Pax (with Baggage)"
    },
    {
        title: "Nissan Teana 250XV",
        image: "/teana.jpg",
        label: "1–3 Pax (with Baggage)"
    },
    {
        title: "Nissan Caravan",
        image: "/carevn.jpg",
        label: "8–14 Pax (with Baggage)"
    },
    {
        title: "Toyota Prius",
        image: "/prius.jpg",
        label: "1–3 Pax (with Baggage)"
    }
];
function VehicleCarousel() {
    const [showModal, setShowModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedVehicle, setSelectedVehicle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const openModal = (vehicle)=>{
        setSelectedVehicle(vehicle);
        setShowModal(true);
    };
    const closeModal = ()=>setShowModal(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        id: "vehicles",
        className: "py-16 bg-[#f8fcff]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-3xl font-bold mb-8 text-gray-800",
                        children: "Rent a Car, Van, Luxury Car and Bus"
                    }, void 0, false, {
                        fileName: "[project]/src/components/VehicleCarousel.jsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Swiper"], {
                        modules: [
                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__["Navigation"],
                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__["Pagination"],
                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$autoplay$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Autoplay$3e$__["Autoplay"]
                        ],
                        spaceBetween: 20,
                        slidesPerView: 1,
                        pagination: {
                            clickable: true
                        },
                        autoplay: {
                            delay: 3000
                        },
                        breakpoints: {
                            640: {
                                slidesPerView: 2.2
                            },
                            1024: {
                                slidesPerView: 3.2
                            }
                        },
                        children: items.map((it)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "carousel-card bg-white p-4 rounded-xl shadow-md",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative h-48 w-full rounded-xl overflow-hidden",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                src: it.image,
                                                alt: it.title,
                                                fill: true,
                                                className: "object-cover"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/VehicleCarousel.jsx",
                                                lineNumber: 76,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VehicleCarousel.jsx",
                                            lineNumber: 75,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                            className: "mt-4 text-lg text-gray-800 font-semibold",
                                            children: it.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VehicleCarousel.jsx",
                                            lineNumber: 84,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-gray-500 text-sm",
                                            children: it.label
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VehicleCarousel.jsx",
                                            lineNumber: 87,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-4 flex gap-3",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "btn-yellow ",
                                                onClick: ()=>openModal(it.title),
                                                children: "Request A Free Quote"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/VehicleCarousel.jsx",
                                                lineNumber: 90,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VehicleCarousel.jsx",
                                            lineNumber: 89,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/VehicleCarousel.jsx",
                                    lineNumber: 74,
                                    columnNumber: 15
                                }, this)
                            }, it.title, false, {
                                fileName: "[project]/src/components/VehicleCarousel.jsx",
                                lineNumber: 73,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/VehicleCarousel.jsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/VehicleCarousel.jsx",
                lineNumber: 56,
                columnNumber: 7
            }, this),
            showModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VehicleQuoteModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                vehicle: selectedVehicle,
                closeModal: closeModal
            }, void 0, false, {
                fileName: "[project]/src/components/VehicleCarousel.jsx",
                lineNumber: 105,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/VehicleCarousel.jsx",
        lineNumber: 55,
        columnNumber: 5
    }, this);
}
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/components/Breadcrumbs.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Breadcrumbs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function Breadcrumbs() {
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    if (!pathname || pathname === "/") return null;
    // Split URL segments
    let segments = pathname.split("/").filter(Boolean);
    // Remove unwanted route from breadcrumb
    const hiddenSegments = [
        "itinerary-inner"
    ];
    segments = segments.filter((seg)=>!hiddenSegments.includes(seg));
    const breadcrumbs = segments.map((seg, i)=>({
            href: "/" + segments.slice(0, i + 1).join("/"),
            label: seg.replace(/-/g, " ")
        }));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "breadcrumb-hero",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "hero-title",
                children: breadcrumbs[breadcrumbs.length - 1].label
            }, void 0, false, {
                fileName: "[project]/src/components/Breadcrumbs.jsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    className: "breadcrumb-nav",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "/",
                                className: "crumb",
                                children: "Home"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Breadcrumbs.jsx",
                                lineNumber: 33,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Breadcrumbs.jsx",
                            lineNumber: 32,
                            columnNumber: 11
                        }, this),
                        breadcrumbs.map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "divider",
                                        children: "/"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Breadcrumbs.jsx",
                                        lineNumber: 40,
                                        columnNumber: 15
                                    }, this),
                                    i === breadcrumbs.length - 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "crumb active",
                                        children: item.label
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Breadcrumbs.jsx",
                                        lineNumber: 43,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: item.href,
                                        className: "crumb",
                                        children: item.label
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Breadcrumbs.jsx",
                                        lineNumber: 45,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, i, true, {
                                fileName: "[project]/src/components/Breadcrumbs.jsx",
                                lineNumber: 39,
                                columnNumber: 13
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Breadcrumbs.jsx",
                    lineNumber: 31,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Breadcrumbs.jsx",
                lineNumber: 30,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Breadcrumbs.jsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/TourQuote.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>QuoteForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Breadcrumbs$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Breadcrumbs.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
function QuoteForm() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto px-4 mt-10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Breadcrumbs$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/TourQuote.jsx",
                lineNumber: 8,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-lg text-gray-700 mt-4",
                children: "Please fill out the form below for a general quote request."
            }, void 0, false, {
                fileName: "[project]/src/components/TourQuote.jsx",
                lineNumber: 10,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                method: "POST",
                id: "quoteForm",
                noValidate: true,
                className: "mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 gap-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white shadow-md rounded-xl p-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                        className: "text-xl font-semibold mb-4",
                                        children: "Personal Information"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 18,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "first_name",
                                                        className: "block font-medium text-gray-700",
                                                        children: "First Name"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 22,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        id: "first_name",
                                                        name: "first_name",
                                                        type: "text",
                                                        placeholder: "Enter your first name",
                                                        required: true,
                                                        className: "mt-1 w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 25,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 21,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "last_name",
                                                        className: "block font-medium text-gray-700",
                                                        children: "Last Name"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 36,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        id: "last_name",
                                                        name: "last_name",
                                                        type: "text",
                                                        placeholder: "Enter your last name",
                                                        required: true,
                                                        className: "mt-1 w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 39,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 35,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 20,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "country",
                                                className: "block font-medium text-gray-700",
                                                children: "Country"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 51,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "country",
                                                name: "country",
                                                type: "text",
                                                placeholder: "Enter your country",
                                                required: true,
                                                className: "mt-1 w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 54,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 50,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "email",
                                                className: "block font-medium text-gray-700",
                                                children: "Email Address"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 65,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "email",
                                                name: "email",
                                                type: "email",
                                                placeholder: "Enter your email",
                                                required: true,
                                                className: "mt-1 w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 68,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 64,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "phone",
                                                className: "block font-medium text-gray-700",
                                                children: "Phone Number"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 79,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "phone",
                                                name: "phone",
                                                type: "text",
                                                placeholder: "Enter your phone number",
                                                required: true,
                                                className: "mt-1 w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 82,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 78,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/TourQuote.jsx",
                                lineNumber: 17,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white shadow-md rounded-xl p-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                        className: "text-xl font-semibold mb-4",
                                        children: "Trip Details"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 95,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "num_adults",
                                                        className: "block font-medium text-gray-700",
                                                        children: "Number of Adults"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 99,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        id: "num_adults",
                                                        name: "num_adults",
                                                        type: "number",
                                                        min: "1",
                                                        required: true,
                                                        className: "mt-1 w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 102,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 98,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "num_children",
                                                        className: "block font-medium text-gray-700",
                                                        children: "Children"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 113,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        id: "num_children",
                                                        name: "num_children",
                                                        type: "number",
                                                        min: "0",
                                                        defaultValue: "0",
                                                        className: "mt-1 w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 116,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 112,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 97,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-1 md:grid-cols-2 gap-4 mt-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "date_from",
                                                        className: "block font-medium text-gray-700",
                                                        children: "From"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 129,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        id: "date_from",
                                                        name: "date_from",
                                                        type: "text",
                                                        placeholder: "Select start date",
                                                        required: true,
                                                        readOnly: true,
                                                        className: "mt-1 w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 flatpickr-input"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 132,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 128,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        htmlFor: "date_to",
                                                        className: "block font-medium text-gray-700",
                                                        children: "To"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 144,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        id: "date_to",
                                                        name: "date_to",
                                                        type: "text",
                                                        placeholder: "Select end date",
                                                        required: true,
                                                        readOnly: true,
                                                        className: "mt-1 w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 flatpickr-input"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/TourQuote.jsx",
                                                        lineNumber: 147,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 143,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 127,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "message",
                                                className: "block font-medium text-gray-700",
                                                children: "Message"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 160,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                id: "message",
                                                name: "message",
                                                rows: "4",
                                                placeholder: "Enter any additional details or requirements",
                                                className: "mt-1 w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/TourQuote.jsx",
                                                lineNumber: 163,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 159,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/TourQuote.jsx",
                                lineNumber: 94,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/TourQuote.jsx",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "submit",
                            className: "bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg shadow-md",
                            children: "Request A Tailored Solution"
                        }, void 0, false, {
                            fileName: "[project]/src/components/TourQuote.jsx",
                            lineNumber: 176,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/TourQuote.jsx",
                        lineNumber: 175,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-8 bg-white shadow-md rounded-xl p-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                className: "text-xl font-semibold mb-4",
                                children: "Quote Includes:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/TourQuote.jsx",
                                lineNumber: 186,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                className: "space-y-2 text-gray-700",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: "A/C Vehicle"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 189,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: "English Speaking Tourist Chauffeur"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 190,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: "Fuel, Tolls, Parking Expenses"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 191,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: "Chauffeur Accommodation & Meals"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 192,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: "Hotel Accommodation and Meals (Upon Customer Request)"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 193,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: "Insurance While Travelling On Our Vehicles"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 194,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: "All Government Taxes"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/TourQuote.jsx",
                                        lineNumber: 195,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/TourQuote.jsx",
                                lineNumber: 188,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-4 bg-green-100 border border-green-300 text-green-700 p-4 rounded-lg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: "No Hidden Charges At All."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/TourQuote.jsx",
                                    lineNumber: 199,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/TourQuote.jsx",
                                lineNumber: 198,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/TourQuote.jsx",
                        lineNumber: 185,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/TourQuote.jsx",
                lineNumber: 14,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/TourQuote.jsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/app/itinerary/tourData.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tours",
    ()=>tours
]);
const tours = [
    {
        slug: "14-days-diversity-tour",
        title: "14 Days Diversity Tour",
        days: "14 Day / 13 Night",
        pax: "Any size",
        images: [
            "/17114457010.jpg",
            "/17115409501.jpg",
            "/17115409502.jpg",
            "/17115409503.jpg"
        ],
        desc: `Embark on a mesmerizing 14-day journey through the diverse landscapes and rich cultural tapestry of Sri Lanka. Starting in Negombo, the coastal town sets the tone for the adventure, blending native hospitality and vibrant local culture. The journey unfolds with a visit to Anuradhapura, an ancient city steeped in heritage, housing sacred sites like the Bodhi Tree and Ruwanwelisaya. As you ascend the iconic Sigiriya Rock Fortress and explore the ancient marvels of Polonnaruwa, the tour delves deep into the island's cultural roots. Kandy, the cultural capital, invites you to witness the Temple of the Tooth Relic and immerse yourself in the lush Royal Botanical Gardens.

The exploration extends to the cool climes of Nuwara Eliya, where tea plantations and the breathtaking Horton Plains National Park await. Ella, with its scenic waterfalls and picturesque landscapes, offers an enchanting respite before venturing into the untamed beauty of Yala National Park. Safaris unveil Sri Lanka's diverse wildlife, from elusive leopards to majestic elephants. Throughout this unforgettable journey, a comfortable car and experienced driver ensure seamless travel.

From the tranquility of tea plantations to the thrill of wildlife adventures, this tour promises a perfect blend of cultural immersion and exploration, creating lasting memories in the heart of the Indian Ocean.`,
        itinerary: [
            {
                day: "Day 1 - Arrival in Negombo",
                content: `
• Arrive in Negombo and check into your hotel.
• Relax and recover after your journey.
• Explore Negombo Beach and enjoy the vibrant local atmosphere.
    `
            },
            {
                day: "Day 2-3 - Anuradhapura",
                content: `
• Drive to Anuradhapura (approx. 4–5 hours).
• Explore the sacred Jaya Sri Maha Bodhi.
• Visit Ruwanwelisaya and Thuparamaya.
• Discover UNESCO World Heritage archaeological sites.
• Spend two nights exploring the ancient capital.
    `
            },
            {
                day: "Day 4-5 - Sigiriya and Dambulla",
                content: `
• Drive to Sigiriya (approx. 2–3 hours).
• Climb Sigiriya Rock Fortress and see the ancient frescoes.
• Visit the Dambulla Cave Temple.
• Explore nearby cultural villages and viewpoints.
• Spend two nights in Sigiriya/Dambulla.
    `
            },
            {
                day: "Day 6-7 - Kandy",
                content: `
• Drive to Kandy (approx. 2–3 hours).
• Visit the Temple of the Tooth Relic.
• Explore the Royal Botanical Gardens.
• Enjoy a traditional Kandyan cultural dance show.
• Visit Kandy Garrison Cemetery and Udawattakele Forest Reserve.
• Spend two nights in Kandy.
    `
            },
            {
                day: "Day 8-9 - Nuwara Eliya",
                content: `
• Drive to Nuwara Eliya (approx. 2–3 hours).
• Visit a tea plantation and witness tea-making.
• Explore scenic highland landscapes.
• Enjoy the cool climate of “Little England.”
• Visit Horton Plains National Park and World's End.
• Spend two nights in Nuwara Eliya.
    `
            },
            {
                day: "Day 10-11 - Ella",
                content: `
• Drive to Ella (approx. 2 hours).
• Visit the famous Nine Arch Bridge.
• Hike Little Adam's Peak.
• Enjoy a scenic train ride with stunning mountain views.
• Explore waterfalls and lush greenery.
• Spend two nights in Ella.
    `
            },
            {
                day: "Day 12-13 - Yala National Park",
                content: `
• Drive to Yala National Park (approx. 2–3 hours).
• Embark on wildlife safaris.
• Spot leopards, elephants, sloth bears, and bird species.
• Stay in a safari lodge close to nature.
• Spend two nights enjoying Yala’s wilderness.
    `
            },
            {
                day: "Day 14 - Departure from Colombo",
                content: `
• Drive back to Colombo (approx. 4–5 hours).
• Explore Galle Face Green or enjoy last-minute shopping.
• Transfer to Bandaranaike International Airport for your departure.
    `
            }
        ],
        includes: [
            {
                icon: "⛽",
                title: "Free Fuel",
                desc: "Fuel to keep your journey rolling"
            },
            {
                icon: "🏨",
                title: "Accommodation",
                desc: "Comfortable hotels included"
            },
            {
                icon: "👨‍✈️",
                title: "Experienced Guide",
                desc: "Experienced and trained guide"
            },
            {
                icon: "🅿️",
                title: "Parking Fees",
                desc: "Parking fees for worry-free stops."
            }
        ]
    },
    {
        slug: "4-days-flagship-itinerary",
        title: "4 Days flagship Itinerary",
        days: "4 Day / 3 Night",
        pax: "Any size",
        images: [
            "/17114469141.jpg",
            "/17299371410.jpeg",
            "/17299380390.JPG",
            "/17299380391.jpg"
        ],
        desc: `Embark on an exhilarating 4-day adventure through the heart of Sri Lanka with our meticulously curated itinerary. Our tailored itineraries offer the perfect blend of exploration and relaxation,catering to solo travelers, couples seeking romantic getaways, and families on the lookout for exciting excursions. With the convenience of a skilled driver, your journey becomes seamless,allowing you to focus on the breathtaking landscapes and rich cultural experiences. Immerse yourself in the romantic allure of Kandy, surrounded by historic temples and verdant tea plantations. For those seeking flexibility, we recommend the option to rent a car, providing the freedom to discover hidden gems along the way. Indulge in the authentic flavors of Ceylon tea,enhancing your adventure with every sip. Join us on this unforgettable expedition, where each moment offers a unique blend of adventure and tranquility amidst the enchanting landscapes of Sri Lanka.`,
        itinerary: [
            {
                day: "Day 1 - Arrival in Colombo",
                content: `• Arrive at Bandaranaike International Airport in Colombo.
• Transfer to your hotel and check-in.
• Spend the day relaxing to recover from the journey.
• In the evening, explore local markets or enjoy a leisurely stroll near your accommodation.
• Overnight stay in Colombo.`
            },
            {
                day: "Day 2 - Colombo to Kandy",
                content: `• Morning departure to Kandy (approximately 3–4 hours by car or train).
• Visit the Temple of the Tooth Relic, a significant Buddhist shrine.
• Explore the Peradeniya Royal Botanic Gardens.
• Stroll around Kandy Lake.
• Optional: Attend a traditional Kandyan dance performance in the evening.
• Overnight stay in Kandy.`
            },
            {
                day: "Day 3 - Kandy to Dambulla/Sigiriya",
                content: `• Morning drive to Dambulla/Sigiriya (approximately 2–3 hours).
• Visit the Dambulla Cave Temple or climb Sigiriya Rock Fortress.
• Explore the ancient city of Polonnaruwa (if time allows).
• Overnight stay in Dambulla/Sigiriya.`
            },
            {
                day: "Day 4 - Return to Colombo and Departure",
                content: `• Morning return to Colombo (approximately 4–5 hours by car or train).
• Explore Colombo's highlights such as Galle Face Green, Independence Square, and Pettah Market.
• Depending on your departure time, enjoy last-minute shopping.
• Transfer to Bandaranaike International Airport for departure.`
            }
        ],
        includes: [
            {
                icon: "⛽",
                title: "Free Fuel",
                desc: "Fuel to keep your journey rolling"
            },
            {
                icon: "🏨",
                title: "Accommodation",
                desc: "Comfortable hotels included"
            },
            {
                icon: "👨‍✈️",
                title: "Experienced Guide",
                desc: "Experienced and trained guide"
            },
            {
                icon: "🅿️",
                title: "Parking Fees",
                desc: "Parking fees for worry-free stops."
            }
        ]
    },
    {
        slug: "12-days-cultural-heritage-tour",
        title: "12 Days Cultural & Heritage Tour",
        days: "12 Day / 11 Night",
        pax: "Any size",
        images: [
            "/17205182150.jpg",
            "/17205182151.jpg",
            "/17299379120.jpg",
            "/17299379131.jpg",
            "/17299379132.jpg"
        ],
        desc: `Embark on a 12-day odyssey through the cultural and heritage wonders of Sri Lanka, commencing in the vibrant coastal town of Negombo. As the journey unfolds, the ancient city of Anuradhapura beckons with its sacred Bodhi Tree and majestic ruins, showcasing the country's rich heritage. The adventure continues with the iconic Sigiriya Rock Fortress, a testament to ancient engineering marvels, complemented by the cultural splendors of Dambulla Cave Temple. In Kandy, the cultural capital, the Temple of the Tooth Relic captivates with its spiritual aura, while the lush landscapes of Nuwara Eliya offer a traditional tea plantation experience. The exploration extends to Galle, a coastal gem adorned with the UNESCO-listed Galle Fort, inviting visitors to wander through its cobbled streets steeped in history. Throughout this immersive tour, a comfortable car and driver facilitate seamless travel, ensuring you can fully indulge in the warmth of Sri Lankan hospitality and uncover the nation's rich cultural tapestry. From the tranquil tea estates to the bustling heritage sites, this itinerary promises an enchanting blend of exploration and relaxation, providing an ideal escape for those seeking traditional getaways infused with native charm`,
        itinerary: [
            {
                day: "Day 1 - Arrival in Negombo",
                content: `
• Arrive in Negombo, check into your hotel, and relax after your journey.
• Explore Negombo Beach and the local fish market.
    `
            },
            {
                day: "Day 2-3 - Anuradhapura",
                content: `
• Drive to Anuradhapura (approx. 4–5 hours).
• Spend two nights exploring the ancient city's archaeological and historical sites,
  including the sacred Bodhi Tree, Ruwanwelisaya, and Thuparamaya.
    `
            },
            {
                day: "Day 4-5 - Sigiriya and Dambulla",
                content: `
• Drive to Sigiriya (approx. 1–2 hours).
• Climb the iconic Sigiriya Rock Fortress.
• Visit the Dambulla Cave Temple.
• Stay for two nights to explore more sites like Polonnaruwa, another ancient city.
    `
            },
            {
                day: "Day 6-7 - Kandy",
                content: `
• Drive to Kandy (approx. 2–3 hours).
• Visit the Temple of the Tooth Relic and explore the Royal Botanical Gardens.
• Enjoy a cultural dance performance.
• Explore more attractions, including the Kandy Garrison Cemetery 
  and the Udawattakele Forest Reserve.
    `
            },
            {
                day: "Day 8-9 - Nuwara Eliya",
                content: `
• Drive to Nuwara Eliya (approx. 2–3 hours).
• Visit a tea plantation and learn about the tea-making process.
• Explore the beautiful landscapes and enjoy the cool climate.
• Spend two nights and visit Horton Plains National Park and World's End.
    `
            },
            {
                day: "Day 10-11 - Galle",
                content: `
• Drive to Galle (approx. 5–6 hours).
• Explore Galle Fort, a UNESCO World Heritage Site.
• Visit the Galle Maritime Museum and stroll through the historic narrow streets.
• Spend two nights relaxing on Unawatuna Beach and exploring nearby attractions.
    `
            },
            {
                day: "Day 12 - Departure from Colombo",
                content: `
• Drive to Colombo (approx. 2–3 hours).
• Briefly explore Colombo — Independence Square or Gangaramaya Temple.
• Depart from Colombo for your return flight.
    `
            }
        ],
        includes: [
            {
                icon: "⛽",
                title: "Free Fuel",
                desc: "Fuel to keep your journey rolling"
            },
            {
                icon: "🏨",
                title: "Accommodation",
                desc: "Comfortable hotels included"
            },
            {
                icon: "👨‍✈️",
                title: "Experienced Guide",
                desc: "Experienced and trained guide"
            },
            {
                icon: "🅿️",
                title: "Parking Fees",
                desc: "Parking fees for worry-free stops."
            }
        ]
    },
    {
        slug: "10-days-southern-beach-tour",
        title: "10 Days Southern Beach Tour",
        days: "10 Day / 9 Night",
        pax: "Any size",
        images: [
            "/17115433630.jpeg",
            "/17115433631.jpg",
            "/17115433632.jpeg",
            "/17115433633.jpeg"
        ],
        desc: `Embark on a 10-day coastal odyssey along the sun-kissed shores of southern Sri Lanka, commencing in the vibrant coastal town of Negombo. Your journey unfolds with two idyllic nights in Bentota, a beach haven known for its golden sands and thrilling water activities. Cruise the Bentota River amidst swaying coconut palms, immersing yourself in the tropical landscape. Galle, a UNESCO World Heritage Site, beckons next, captivating travelers with its colonial charm within the fortified Galle Fort. As you bask in the historical ambiance, the maritime museum and cobblestone streets unfold tales of a bygone era. Mirissa, a beach enthusiast's delight, welcomes you next with two nights of oceanic wonders. Dive into the adventure with a whale-watching tour, an unforgettable encounter with majestic marine life. Tangalle, a coastal gem, invites you to unwind on Hiriketiya Beach, where tranquil turquoise waters meet pristine sands.

Your journey concludes in Colombo, but not before experiencing the untouched beauty of Tangalle's Goyambokka Beach. The relaxing atmosphere, coupled with the rhythmic sounds of the ocean, creates a haven for beach lovers. Throughout this coastal sojourn, a comfortable car and driver ensure seamless travel, allowing you to relish the cultural tapestry, adventure, and warm hospitality of Sri Lanka. From cultural immersions to beachside sunbathing, this itinerary promises a perfect blend of relaxation and exploration, making it an ideal escape for those seeking coastal getaways enriched with culture and adventure.`,
        itinerary: [
            {
                day: "Day 1 - Arrival in Negombo",
                content: `
• Arrive in Negombo, check into your hotel, and unwind.
• Explore Negombo Beach and its vibrant local atmosphere.
    `
            },
            {
                day: "Day 2-3 - Bentota",
                content: `
• Drive to Bentota (approx. 2–3 hours).
• Spend two nights exploring Bentota's beautiful beaches and engaging in water activities.
• Visit the Brief Garden and the Bentota Turtle Hatchery.
    `
            },
            {
                day: "Day 4-5 - Galle",
                content: `
• Drive to Galle (approx. 1–2 hours).
• Explore Galle Fort, a UNESCO World Heritage Site, over two days.
• Wander through the Dutch Reformed Church and the charming streets of the fort.
• Visit the Galle Maritime Museum.
    `
            },
            {
                day: "Day 6-7 - Mirissa",
                content: `
• Head to Mirissa (approx. 1–2 hours).
• Relax on Mirissa Beach and enjoy its laid-back atmosphere.
• Take a whale-watching tour (seasonal).
• Explore Coconut Tree Hill for panoramic views.
    `
            },
            {
                day: "Day 8-9 - Tangalle",
                content: `
• Drive to Tangalle (approx. 2–3 hours).
• Spend two nights exploring Hiriketiya Beach and Goyambokka Beach.
• Relax on the pristine sandy shores and enjoy the tranquil surroundings.
    `
            }
        ],
        includes: [
            {
                icon: "⛽",
                title: "Free Fuel",
                desc: "Fuel to keep your journey rolling"
            },
            {
                icon: "🏨",
                title: "Accommodation",
                desc: "Comfortable hotels included"
            },
            {
                icon: "👨‍✈️",
                title: "Experienced Guide",
                desc: "Experienced and trained guide"
            },
            {
                icon: "🅿️",
                title: "Parking Fees",
                desc: "Parking fees for worry-free stops."
            }
        ]
    },
    {
        slug: "7-days-grand-tour",
        title: "7 Days’ Grand tour.",
        days: "7 Day / 6 Night",
        pax: "Any size",
        images: [
            "/17115440022.jpg",
            "/17299381110.jpg",
            "/17299381141.jpeg",
            "/17299387620.jpg"
        ],
        desc: `Embark on a mesmerizing 7-day journey through the diverse landscapes of Sri Lanka, starting in the vibrant coastal town of Negombo. Kick off your adventure with a relaxing day at Negombo Beach, known for its golden sands and bustling fish market. The next destination is the cultural heart of the island – Kandy. Immerse yourself in the rich cultural tapestry with a visit to the Temple of the Tooth Relic and witness the vibrant Kandyan cultural dance. The journey continues on a scenic train ride to Ella, a charming hill station surrounded by lush tea plantations. Explore the iconic Nine Arch Bridge and savor the tranquility atop Little Adam's Peak.

Continue the exploration with a thrilling safari in Yala National Park, home to elusive leopards and diverse wildlife. As you journey to the coastal haven of Mirissa, relish the hospitality of Sri Lanka's coastal communities. A whale-watching tour offers an exciting marine adventure before heading to the historic Galle Fort. Wander through its cobbled streets steeped in culture and history. The final leg takes you to Colombo, where you can discover the city's unique blend of modernity and tradition, exemplified by the Gangaramaya Temple and Independence Square. Throughout your tour, a comfortable car and driver ensure seamless travel, allowing you to indulge in the beauty of each destination and enjoy a perfect blend of relaxation and adventure in this exotic getaway`,
        itinerary: [
            {
                day: "Day 1 - Arrival in Negombo",
                content: `
• Arrive in Negombo, check into your hotel, and rest after your journey.
• Explore Negombo Beach and the local fish market.
• Enjoy a relaxing evening by the beach.
    `
            },
            {
                day: "Day 2 - Negombo to Kandy",
                content: `
• Drive to Kandy (approx. 3–4 hours).
• Visit the Temple of the Tooth Relic.
• Explore the Royal Botanical Gardens.
• Enjoy a traditional Kandyan cultural dance performance in the evening.
    `
            },
            {
                day: "Day 3 - Kandy to Ella",
                content: `
• Take a scenic train ride from Kandy to Ella (approx. 6 hours).
• Visit the Nine Arch Bridge and Little Adam's Peak in Ella.
• Explore Ella town and enjoy the laid-back atmosphere.
    `
            },
            {
                day: "Day 4 - Ella to Yala National Park",
                content: `
• Drive to Yala National Park (approx. 2–3 hours).
• Embark on an afternoon safari in Yala National Park, famous for its leopard population and diverse wildlife.
• Spend the night at a hotel near the park.
    `
            },
            {
                day: "Day 5 - Yala to Mirissa",
                content: `
• Take a morning safari in Yala (if you didn't do one the previous afternoon).
• Drive to Mirissa (approx. 3–4 hours).
• Relax on Mirissa Beach and enjoy the sunset.
• Explore the vibrant beachside nightlife.
    `
            },
            {
                day: "Day 6 - Mirissa to Galle",
                content: `
• Visit the famous Mirissa Fishermen's Harbour and enjoy a whale-watching tour (seasonal).
• Drive to Galle (approx. 1–2 hours).
• Explore Galle Fort, a UNESCO World Heritage Site, in the afternoon.
• Wander through the charming streets of Galle and experience its unique blend of history and modernity.
    `
            },
            {
                day: "Day 7 - Departure from Colombo",
                content: `
• Drive to Colombo (approx. 2–3 hours).
• If time permits, explore the city, visit the Gangaramaya Temple, and stroll through Independence Square.
• Depart from Colombo.
    `
            }
        ],
        includes: [
            {
                icon: "⛽",
                title: "Free Fuel",
                desc: "Fuel to keep your journey rolling"
            },
            {
                icon: "🏨",
                title: "Accommodation",
                desc: "Comfortable hotels included"
            },
            {
                icon: "👨‍✈️",
                title: "Experienced Guide",
                desc: "Experienced and trained guide"
            },
            {
                icon: "🅿️",
                title: "Parking Fees",
                desc: "Parking fees for worry-free stops."
            }
        ]
    }
];
}),
"[project]/src/components/ItineraryGrid.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ItineraryGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/index.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/pagination.mjs [app-ssr] (ecmascript) <export default as Pagination>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$TourQuote$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/TourQuote.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$itinerary$2f$tourData$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/itinerary/tourData.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
function ItineraryGrid() {
    const [showModal, setShowModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedTour, setSelectedTour] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const openModal = (tourName)=>{
        setSelectedTour(tourName);
        setShowModal(true);
    };
    const closeModal = ()=>setShowModal(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-14 bg-slate-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4 sm:px-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-3xl font-bold mb-8 text-gray-800 mt-6 text-center md:text-left",
                        children: "Our Popular Itineraries"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$itinerary$2f$tourData$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["tours"].map((t, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                                className: "tour-card",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Swiper"], {
                                        modules: [
                                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__["Pagination"]
                                        ],
                                        pagination: {
                                            clickable: true
                                        },
                                        className: "tour-img-slider",
                                        children: t.images.map((img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative h-60 sm:h-64 rounded-xl overflow-hidden",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        src: img,
                                                        alt: t.title,
                                                        fill: true,
                                                        className: "object-cover"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                        lineNumber: 69,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                    lineNumber: 68,
                                                    columnNumber: 21
                                                }, this)
                                            }, idx, false, {
                                                fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                lineNumber: 67,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                        lineNumber: 61,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between mt-3 text-gray-600 text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-lg",
                                                        children: "👥"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                        lineNumber: 83,
                                                        columnNumber: 19
                                                    }, this),
                                                    " ",
                                                    t.pax
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                lineNumber: 82,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-lg",
                                                        children: "📅"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                        lineNumber: 86,
                                                        columnNumber: 19
                                                    }, this),
                                                    " ",
                                                    t.days
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                lineNumber: 85,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                        lineNumber: 81,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "mt-4 text-xl font-semibold text-gray-800",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: `/itinerary/itinerary-inner/${t.slug}`,
                                            className: "hover:text-blue-600 transition",
                                            children: t.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ItineraryGrid.jsx",
                                            lineNumber: 92,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                        lineNumber: 91,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-gray-600 mt-2 line-clamp-3",
                                        children: t.desc
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                        lineNumber: 101,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "btn-yellow mt-5 w-full sm:w-auto",
                                        onClick: ()=>openModal(t.title),
                                        children: "Request A Free Quote"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                        lineNumber: 106,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, i, true, {
                                fileName: "[project]/src/components/ItineraryGrid.jsx",
                                lineNumber: 59,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ItineraryGrid.jsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            showModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$TourQuote$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                tour: selectedTour,
                closeModal: closeModal
            }, void 0, false, {
                fileName: "[project]/src/components/ItineraryGrid.jsx",
                lineNumber: 118,
                columnNumber: 21
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ItineraryGrid.jsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b307855a._.js.map