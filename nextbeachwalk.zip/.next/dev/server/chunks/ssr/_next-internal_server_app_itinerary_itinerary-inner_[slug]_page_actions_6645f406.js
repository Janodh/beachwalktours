module.exports = [
"[project]/.next-internal/server/app/itinerary/itinerary-inner/[slug]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_itinerary_itinerary-inner_%5Bslug%5D_page_actions_6645f406.js.map