(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_93887fe8._.js",
  "static/chunks/src_e222b422._.js",
  "static/chunks/src_components_Breadcrumbs_5c8b8ca9.css"
],
    source: "dynamic"
});
