(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/Breadcrumbs.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Breadcrumbs
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function Breadcrumbs() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18);
    if ($[0] !== "09c06761d62d310c1775af28dfb4903fe87deb6ffb339ef326d45b9fc6b861f9") {
        for(let $i = 0; $i < 18; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "09c06761d62d310c1775af28dfb4903fe87deb6ffb339ef326d45b9fc6b861f9";
    }
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    if (!pathname || pathname === "/") {
        return null;
    }
    let t0;
    let t1;
    let t2;
    let t3;
    let t4;
    if ($[1] !== pathname) {
        let segments = pathname.split("/").filter(Boolean);
        let t5;
        if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = [
                "itinerary-inner"
            ];
            $[7] = t5;
        } else {
            t5 = $[7];
        }
        const hiddenSegments = t5;
        let t6;
        if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = ({
                "Breadcrumbs[segments.filter()]": (seg)=>!hiddenSegments.includes(seg)
            })["Breadcrumbs[segments.filter()]"];
            $[8] = t6;
        } else {
            t6 = $[8];
        }
        segments = segments.filter(t6);
        const breadcrumbs = segments.map({
            "Breadcrumbs[segments.map()]": (seg_0, i)=>({
                    href: "/" + segments.slice(0, i + 1).join("/"),
                    label: seg_0.replace(/-/g, " ")
                })
        }["Breadcrumbs[segments.map()]"]);
        t3 = "breadcrumb-hero";
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "hero-title",
            children: breadcrumbs[breadcrumbs.length - 1].label
        }, void 0, false, {
            fileName: "[project]/src/components/Breadcrumbs.jsx",
            lineNumber: 51,
            columnNumber: 10
        }, this);
        t0 = "breadcrumb-nav";
        if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
            t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: "/",
                    className: "crumb",
                    children: "Home"
                }, void 0, false, {
                    fileName: "[project]/src/components/Breadcrumbs.jsx",
                    lineNumber: 54,
                    columnNumber: 16
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Breadcrumbs.jsx",
                lineNumber: 54,
                columnNumber: 12
            }, this);
            $[9] = t1;
        } else {
            t1 = $[9];
        }
        t2 = breadcrumbs.map({
            "Breadcrumbs[breadcrumbs.map()]": (item, i_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                    className: "flex items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "divider",
                            children: "/"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Breadcrumbs.jsx",
                            lineNumber: 60,
                            columnNumber: 100
                        }, this),
                        i_0 === breadcrumbs.length - 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "crumb active",
                            children: item.label
                        }, void 0, false, {
                            fileName: "[project]/src/components/Breadcrumbs.jsx",
                            lineNumber: 60,
                            columnNumber: 168
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: item.href,
                            className: "crumb",
                            children: item.label
                        }, void 0, false, {
                            fileName: "[project]/src/components/Breadcrumbs.jsx",
                            lineNumber: 60,
                            columnNumber: 221
                        }, this)
                    ]
                }, i_0, true, {
                    fileName: "[project]/src/components/Breadcrumbs.jsx",
                    lineNumber: 60,
                    columnNumber: 56
                }, this)
        }["Breadcrumbs[breadcrumbs.map()]"]);
        $[1] = pathname;
        $[2] = t0;
        $[3] = t1;
        $[4] = t2;
        $[5] = t3;
        $[6] = t4;
    } else {
        t0 = $[2];
        t1 = $[3];
        t2 = $[4];
        t3 = $[5];
        t4 = $[6];
    }
    let t5;
    if ($[10] !== t0 || $[11] !== t1 || $[12] !== t2) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                className: t0,
                children: [
                    t1,
                    t2
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Breadcrumbs.jsx",
                lineNumber: 77,
                columnNumber: 15
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/Breadcrumbs.jsx",
            lineNumber: 77,
            columnNumber: 10
        }, this);
        $[10] = t0;
        $[11] = t1;
        $[12] = t2;
        $[13] = t5;
    } else {
        t5 = $[13];
    }
    let t6;
    if ($[14] !== t3 || $[15] !== t4 || $[16] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: t3,
            children: [
                t4,
                t5
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Breadcrumbs.jsx",
            lineNumber: 87,
            columnNumber: 10
        }, this);
        $[14] = t3;
        $[15] = t4;
        $[16] = t5;
        $[17] = t6;
    } else {
        t6 = $[17];
    }
    return t6;
}
_s(Breadcrumbs, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = Breadcrumbs;
var _c;
__turbopack_context__.k.register(_c, "Breadcrumbs");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/vehicle-rent/page.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VehicleRentPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/navigation.mjs [app-client] (ecmascript) <export default as Navigation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/pagination.mjs [app-client] (ecmascript) <export default as Pagination>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Breadcrumbs$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Breadcrumbs.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
function VehicleRentPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "c089a237e94598d3ac1da2749e8fd8a935d81b07ef31aaacafc48b39cc3a199f") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c089a237e94598d3ac1da2749e8fd8a935d81b07ef31aaacafc48b39cc3a199f";
    }
    const [showModal, setShowModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedVehicle, setSelectedVehicle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = ({
            "VehicleRentPage[openModal]": (vehicle)=>{
                setSelectedVehicle(vehicle);
                setShowModal(true);
            }
        })["VehicleRentPage[openModal]"];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const openModal = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "VehicleRentPage[closeModal]": ()=>setShowModal(false)
        })["VehicleRentPage[closeModal]"];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const closeModal = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [
            {
                title: "CHR",
                image: "/chr.jpg",
                label: "5 Pax (with Baggage)"
            },
            {
                title: "Toyota Axio",
                image: "/axio.jpg",
                label: "1\u20133 Pax (with Baggage)"
            },
            {
                title: "Toyota Premio",
                image: "/premio.jpg",
                label: "1\u20133 Pax (with Baggage)"
            },
            {
                title: "Toyota Prius",
                image: "/prius.jpg",
                label: "1\u20133 Pax (with Baggage)"
            },
            {
                title: "Nissan Teana 250XV",
                image: "/teana.jpg",
                label: "1\u20133 Pax (with Baggage)"
            },
            {
                title: "Honda Fit Shuttle",
                image: "/fit-shuttle.jpg",
                label: "1\u20133 Pax (with Baggage)"
            },
            {
                title: "Honda Insight",
                image: "/insight.jpg",
                label: "1\u20133 Pax (with Baggage)"
            },
            {
                title: "Toyota Allion",
                image: "/allion.jpg",
                label: "1\u20133 Pax (with Baggage)"
            },
            {
                title: "Toyota Aqua",
                image: "/aqua.jpg",
                label: "1\u20133 Pax (with Baggage)"
            },
            {
                title: "BMW 520D",
                image: "/bmw520d.jpg",
                label: "1\u20133 Pax (with Baggage)"
            },
            {
                title: "Honda Vezel",
                image: "/vezel.jpg",
                label: "1\u20133 Pax (with Baggage)"
            }
        ];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const cars = t2;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [
            {
                title: "Toyota Hiace KDH",
                image: "/kdh.jpg",
                label: "10 Pax (with Baggage)"
            },
            {
                title: "Toyota Hiace Commuter",
                image: "/hiace.png",
                label: "9\u201315 Pax (with Baggage)"
            },
            {
                title: "Nissan Caravan",
                image: "/carevn.jpg",
                label: "8\u201314 Pax (with Baggage)"
            },
            {
                title: "Mercedes-Benz Vito",
                image: "/vito.jpg",
                label: "1\u20136 Pax (with Baggage)"
            },
            {
                title: "Toyota Alphard",
                image: "/alphard.jpg",
                label: "1\u20136 Pax (with Baggage)"
            },
            {
                title: "Nissan NV200",
                image: "/nv200.jpg",
                label: "1\u20137 Pax (with Baggage)"
            }
        ];
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const vans = t3;
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = [
            {
                title: "Toyota Coaster",
                image: "/coaster.jpg",
                label: "15 Pax (with Baggage)"
            },
            {
                title: "Xiamen Golden Dragon",
                image: "/xiamen.jpg",
                label: "35\u201350 Pax (with Baggage)"
            },
            {
                title: "Mitsubishi Rosa",
                image: "/rosa.jpg",
                label: "20\u201329 Pax (with Baggage)"
            },
            {
                title: "Nissan Civilian",
                image: "/civilian.jpg",
                label: "20\u201329 Pax (with Baggage)"
            },
            {
                title: "Xiamen Golden Dragon Navigator",
                image: "/golden-dragon-nav.jpg",
                label: "45\u201360 Pax (with Baggage)"
            }
        ];
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const buses = t4;
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Breadcrumbs$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 160,
            columnNumber: 10
        }, this);
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-6 vehicle-section",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CategoryCarousel, {
                    title: "Rent a Car With Driver",
                    data: cars,
                    openModal: openModal
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 167,
                    columnNumber: 66
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CategoryCarousel, {
                    title: "Rent A Van With Driver",
                    data: vans,
                    openModal: openModal
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 167,
                    columnNumber: 151
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CategoryCarousel, {
                    title: "Rent A Bus With Driver",
                    data: buses,
                    openModal: openModal
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 167,
                    columnNumber: 236
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 167,
            columnNumber: 10
        }, this);
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] !== selectedVehicle || $[9] !== showModal) {
        t7 = showModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(QuoteModal, {
            vehicle: selectedVehicle,
            closeModal: closeModal
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 174,
            columnNumber: 23
        }, this);
        $[8] = selectedVehicle;
        $[9] = showModal;
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "bg-[#f8fcff] pb-20 bg-section",
            children: [
                t5,
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 183,
            columnNumber: 10
        }, this);
        $[11] = t7;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    return t8;
}
_s(VehicleRentPage, "3hujkKXlnwSvqNs+LxDG902fxVQ=");
_c = VehicleRentPage;
/* ---------- Reusable Category Carousel ---------- */ function CategoryCarousel(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "c089a237e94598d3ac1da2749e8fd8a935d81b07ef31aaacafc48b39cc3a199f") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c089a237e94598d3ac1da2749e8fd8a935d81b07ef31aaacafc48b39cc3a199f";
    }
    const { title, data, openModal } = t0;
    let t1;
    if ($[1] !== title) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-xl font-semibold text-gray-700 mb-6",
            children: title
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 209,
            columnNumber: 10
        }, this);
        $[1] = title;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__["Navigation"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__["Pagination"]
        ];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            clickable: true
        };
        t4 = {
            640: {
                slidesPerView: 2.2
            },
            1024: {
                slidesPerView: 3.2
            }
        };
        $[4] = t3;
        $[5] = t4;
    } else {
        t3 = $[4];
        t4 = $[5];
    }
    let t5;
    if ($[6] !== data || $[7] !== openModal) {
        let t6;
        if ($[9] !== openModal) {
            t6 = ({
                "CategoryCarousel[data.map()]": (item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(VehicleCard, {
                            item: item,
                            openModal: openModal
                        }, void 0, false, {
                            fileName: "[project]/src/app/vehicle-rent/page.js",
                            lineNumber: 247,
                            columnNumber: 79
                        }, this)
                    }, item.title, false, {
                        fileName: "[project]/src/app/vehicle-rent/page.js",
                        lineNumber: 247,
                        columnNumber: 49
                    }, this)
            })["CategoryCarousel[data.map()]"];
            $[9] = openModal;
            $[10] = t6;
        } else {
            t6 = $[10];
        }
        t5 = data.map(t6);
        $[6] = data;
        $[7] = openModal;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[11] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Swiper"], {
            modules: t2,
            spaceBetween: 20,
            slidesPerView: 1.2,
            navigation: true,
            pagination: t3,
            breakpoints: t4,
            children: t5
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 263,
            columnNumber: 10
        }, this);
        $[11] = t5;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    let t7;
    if ($[13] !== t1 || $[14] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mb-16",
            children: [
                t1,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 271,
            columnNumber: 10
        }, this);
        $[13] = t1;
        $[14] = t6;
        $[15] = t7;
    } else {
        t7 = $[15];
    }
    return t7;
}
_c1 = CategoryCarousel;
/* ---------- Vehicle Card ---------- */ function VehicleCard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "c089a237e94598d3ac1da2749e8fd8a935d81b07ef31aaacafc48b39cc3a199f") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c089a237e94598d3ac1da2749e8fd8a935d81b07ef31aaacafc48b39cc3a199f";
    }
    const { item, openModal } = t0;
    let t1;
    if ($[1] !== item.image || $[2] !== item.title) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative h-48 w-full rounded-xl overflow-hidden flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                src: item.image,
                alt: item.title,
                width: 350,
                height: 260,
                className: "object-contain"
            }, void 0, false, {
                fileName: "[project]/src/app/vehicle-rent/page.js",
                lineNumber: 297,
                columnNumber: 108
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 297,
            columnNumber: 10
        }, this);
        $[1] = item.image;
        $[2] = item.title;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    let t2;
    if ($[4] !== item.title) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
            className: "mt-4 text-lg font-semibold text-gray-700",
            children: item.title
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 306,
            columnNumber: 10
        }, this);
        $[4] = item.title;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    let t3;
    if ($[6] !== item.label) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-gray-500 text-sm",
            children: item.label
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 314,
            columnNumber: 10
        }, this);
        $[6] = item.label;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    let t4;
    if ($[8] !== item.title || $[9] !== openModal) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "btn-yellow mt-4 w-fit",
            onClick: {
                "VehicleCard[<button>.onClick]": ()=>openModal(item.title)
            }["VehicleCard[<button>.onClick]"],
            children: "Request A Free Quote"
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 322,
            columnNumber: 10
        }, this);
        $[8] = item.title;
        $[9] = openModal;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== t1 || $[12] !== t2 || $[13] !== t3 || $[14] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "carousel-card bg-white p-4 rounded-xl shadow-sm hover:shadow-lg transition",
            children: [
                t1,
                t2,
                t3,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 333,
            columnNumber: 10
        }, this);
        $[11] = t1;
        $[12] = t2;
        $[13] = t3;
        $[14] = t4;
        $[15] = t5;
    } else {
        t5 = $[15];
    }
    return t5;
}
_c2 = VehicleCard;
/* ---------- Quote Modal Component ---------- */ function QuoteModal(t0) {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(29);
    if ($[0] !== "c089a237e94598d3ac1da2749e8fd8a935d81b07ef31aaacafc48b39cc3a199f") {
        for(let $i = 0; $i < 29; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c089a237e94598d3ac1da2749e8fd8a935d81b07ef31aaacafc48b39cc3a199f";
    }
    const { vehicle, closeModal } = t0;
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [success, setSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    if ($[1] !== vehicle) {
        t1 = async function handleSubmit(e) {
            e.preventDefault();
            setLoading(true);
            const token = await grecaptcha.execute("6LeGmxgsAAAAAL_OhPQVlaPjL-4ioJln-A5uStEQ", {
                action: "submit"
            });
            const formData = new FormData(e.target);
            formData.append("vehicle", vehicle);
            formData.append("recaptcha", token);
            const res = await fetch("/api/send-quote", {
                method: "POST",
                body: formData
            });
            setLoading(false);
            if (res.ok) {
                setSuccess(true);
                e.target.reset();
            }
        };
        $[1] = vehicle;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const handleSubmit = t1;
    let t2;
    if ($[3] !== closeModal) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: closeModal,
            className: "absolute top-3 right-3 text-gray-600 hover:text-black text-xl",
            children: "✕"
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 389,
            columnNumber: 10
        }, this);
        $[3] = closeModal;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-2xl font-semibold mb-4 text-[#1e3a5f]",
            children: "Request A Free Quote"
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 397,
            columnNumber: 10
        }, this);
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== success) {
        t4 = success && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-green-600 mb-4 font-medium",
            children: "✅ Your quote request has been sent successfully!"
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 404,
            columnNumber: 21
        }, this);
        $[6] = success;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] !== vehicle) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "hidden",
            name: "vehicle",
            value: vehicle
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 412,
            columnNumber: 10
        }, this);
        $[8] = vehicle;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    let t7;
    let t8;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Name"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 422,
                    columnNumber: 15
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "name",
                    type: "text",
                    className: "inputBox",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 422,
                    columnNumber: 58
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 422,
            columnNumber: 10
        }, this);
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Email"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 423,
                    columnNumber: 15
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "email",
                    type: "email",
                    className: "inputBox",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 423,
                    columnNumber: 59
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 423,
            columnNumber: 10
        }, this);
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Phone"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 424,
                    columnNumber: 15
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "phone",
                    type: "tel",
                    className: "inputBox",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 424,
                    columnNumber: 59
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 424,
            columnNumber: 10
        }, this);
        $[10] = t6;
        $[11] = t7;
        $[12] = t8;
    } else {
        t6 = $[10];
        t7 = $[11];
        t8 = $[12];
    }
    let t9;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-1/2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Adults"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 435,
                    columnNumber: 33
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "adults",
                    type: "number",
                    className: "inputBox"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 435,
                    columnNumber: 78
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 435,
            columnNumber: 10
        }, this);
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-4",
            children: [
                t9,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-1/2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "font-medium",
                            children: "Children"
                        }, void 0, false, {
                            fileName: "[project]/src/app/vehicle-rent/page.js",
                            lineNumber: 442,
                            columnNumber: 66
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            name: "children",
                            type: "number",
                            className: "inputBox"
                        }, void 0, false, {
                            fileName: "[project]/src/app/vehicle-rent/page.js",
                            lineNumber: 442,
                            columnNumber: 113
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 442,
                    columnNumber: 43
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 442,
            columnNumber: 11
        }, this);
        $[14] = t10;
    } else {
        t10 = $[14];
    }
    let t11;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-1/2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Arrival Date"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 449,
                    columnNumber: 34
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "arrival",
                    type: "date",
                    className: "inputBox"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 449,
                    columnNumber: 85
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 449,
            columnNumber: 11
        }, this);
        $[15] = t11;
    } else {
        t11 = $[15];
    }
    let t12;
    let t13;
    let t14;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-4",
            children: [
                t11,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-1/2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "font-medium",
                            children: "Departure Date"
                        }, void 0, false, {
                            fileName: "[project]/src/app/vehicle-rent/page.js",
                            lineNumber: 458,
                            columnNumber: 67
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            name: "departure",
                            type: "date",
                            className: "inputBox"
                        }, void 0, false, {
                            fileName: "[project]/src/app/vehicle-rent/page.js",
                            lineNumber: 458,
                            columnNumber: 120
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 458,
                    columnNumber: 44
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 458,
            columnNumber: 11
        }, this);
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Country"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 459,
                    columnNumber: 16
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "country",
                    type: "text",
                    className: "inputBox"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 459,
                    columnNumber: 62
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 459,
            columnNumber: 11
        }, this);
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Message"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 460,
                    columnNumber: 16
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                    name: "message",
                    rows: "3",
                    className: "inputBox"
                }, void 0, false, {
                    fileName: "[project]/src/app/vehicle-rent/page.js",
                    lineNumber: 460,
                    columnNumber: 62
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 460,
            columnNumber: 11
        }, this);
        $[16] = t12;
        $[17] = t13;
        $[18] = t14;
    } else {
        t12 = $[16];
        t13 = $[17];
        t14 = $[18];
    }
    const t15 = loading ? "Sending..." : "Submit";
    let t16;
    if ($[19] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            className: "w-full bg-[#1e3a5f] text-white py-3 rounded-xl hover:bg-[#162e4a] transition font-semibold",
            children: t15
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 472,
            columnNumber: 11
        }, this);
        $[19] = t15;
        $[20] = t16;
    } else {
        t16 = $[20];
    }
    let t17;
    if ($[21] !== handleSubmit || $[22] !== t16 || $[23] !== t5) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: handleSubmit,
            className: "space-y-4",
            children: [
                t5,
                t6,
                t7,
                t8,
                t10,
                t12,
                t13,
                t14,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 480,
            columnNumber: 11
        }, this);
        $[21] = handleSubmit;
        $[22] = t16;
        $[23] = t5;
        $[24] = t17;
    } else {
        t17 = $[24];
    }
    let t18;
    if ($[25] !== t17 || $[26] !== t2 || $[27] !== t4) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white w-full max-w-lg rounded-2xl p-8 shadow-xl relative animate-fadeIn \n                  max-h-[100vh] overflow-y-auto",
                children: [
                    t2,
                    t3,
                    t4,
                    t17
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/vehicle-rent/page.js",
                lineNumber: 490,
                columnNumber: 109
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/vehicle-rent/page.js",
            lineNumber: 490,
            columnNumber: 11
        }, this);
        $[25] = t17;
        $[26] = t2;
        $[27] = t4;
        $[28] = t18;
    } else {
        t18 = $[28];
    }
    return t18;
}
_s1(QuoteModal, "YqRSekwUJue4kKje6jZ35rjMwKc=");
_c3 = QuoteModal;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "VehicleRentPage");
__turbopack_context__.k.register(_c1, "CategoryCarousel");
__turbopack_context__.k.register(_c2, "VehicleCard");
__turbopack_context__.k.register(_c3, "QuoteModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_76126169._.js.map