(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_af04c205._.js",
  "static/chunks/src_1c1ddd2f._.js",
  "static/chunks/src_components_2db32c5a._.css"
],
    source: "dynamic"
});
