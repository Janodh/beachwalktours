(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_65123c52._.css",
  "static/chunks/node_modules_dbf6be86._.js",
  "static/chunks/src_9236e1d2._.js"
],
    source: "dynamic"
});
