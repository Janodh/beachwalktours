(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_2fa8d218._.css",
  "static/chunks/node_modules_93887fe8._.js",
  "static/chunks/src_76126169._.js"
],
    source: "dynamic"
});
