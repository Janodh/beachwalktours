(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_0bab768d._.js",
  "static/chunks/src_components_Breadcrumbs_5c8b8ca9.css"
],
    source: "dynamic"
});
