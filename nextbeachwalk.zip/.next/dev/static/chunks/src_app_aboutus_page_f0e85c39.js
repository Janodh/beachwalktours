(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_daa9d9a1._.css",
  "static/chunks/_70050450._.js"
],
    source: "dynamic"
});
