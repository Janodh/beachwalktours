(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/VehicleCarousel.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VehicleCarousel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/navigation.mjs [app-client] (ecmascript) <export default as Navigation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/pagination.mjs [app-client] (ecmascript) <export default as Pagination>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$autoplay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Autoplay$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/autoplay.mjs [app-client] (ecmascript) <export default as Autoplay>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VehicleQuoteModal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/VehicleQuoteModal.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
const items = [
    {
        title: "Toyota Premio",
        image: "/premio.jpg",
        label: "1–3 Pax (with Baggage)"
    },
    {
        title: "Toyota Hiace KDH",
        image: "/kdh.jpg",
        label: "10 Pax (with Baggage)"
    },
    {
        title: "Xiamen Golden Dragon",
        image: "/xiamen.jpg",
        label: "35–50 Pax (with Baggage)"
    },
    {
        title: "Nissan Teana 250XV",
        image: "/teana.jpg",
        label: "1–3 Pax (with Baggage)"
    },
    {
        title: "Nissan Caravan",
        image: "/carevn.jpg",
        label: "8–14 Pax (with Baggage)"
    },
    {
        title: "Toyota Prius",
        image: "/prius.jpg",
        label: "1–3 Pax (with Baggage)"
    }
];
function VehicleCarousel() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    if ($[0] !== "6980a08b75c78cdab68b1f1184a49b41be9d1071852468d2aa04a2de0854403f") {
        for(let $i = 0; $i < 11; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6980a08b75c78cdab68b1f1184a49b41be9d1071852468d2aa04a2de0854403f";
    }
    const [showModal, setShowModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedVehicle, setSelectedVehicle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = ({
            "VehicleCarousel[openModal]": (vehicle)=>{
                setSelectedVehicle(vehicle);
                setShowModal(true);
            }
        })["VehicleCarousel[openModal]"];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const openModal = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "VehicleCarousel[closeModal]": ()=>setShowModal(false)
        })["VehicleCarousel[closeModal]"];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const closeModal = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-3xl font-bold mb-8 text-gray-800",
            children: "Rent a Car, Van, Luxury Car and Bus"
        }, void 0, false, {
            fileName: "[project]/src/components/VehicleCarousel.jsx",
            lineNumber: 70,
            columnNumber: 10
        }, this);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$navigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Navigation$3e$__["Navigation"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__["Pagination"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$autoplay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Autoplay$3e$__["Autoplay"]
        ];
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-6",
            children: [
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Swiper"], {
                    modules: t3,
                    spaceBetween: 20,
                    slidesPerView: 1,
                    pagination: {
                        clickable: true
                    },
                    autoplay: {
                        delay: 3000
                    },
                    breakpoints: {
                        640: {
                            slidesPerView: 2.2
                        },
                        1024: {
                            slidesPerView: 3.2
                        }
                    },
                    children: items.map({
                        "VehicleCarousel[items.map()]": (it)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "carousel-card bg-white p-4 rounded-xl shadow-md",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative h-48 w-full rounded-xl overflow-hidden",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                src: it.image,
                                                alt: it.title,
                                                fill: true,
                                                className: "object-cover"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/VehicleCarousel.jsx",
                                                lineNumber: 96,
                                                columnNumber: 207
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VehicleCarousel.jsx",
                                            lineNumber: 96,
                                            columnNumber: 142
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                            className: "mt-4 text-lg text-gray-800 font-semibold",
                                            children: it.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VehicleCarousel.jsx",
                                            lineNumber: 96,
                                            columnNumber: 289
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-gray-500 text-sm",
                                            children: it.label
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VehicleCarousel.jsx",
                                            lineNumber: 96,
                                            columnNumber: 361
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-4 flex gap-3",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "btn-yellow ",
                                                onClick: {
                                                    "VehicleCarousel[items.map() > <button>.onClick]": ()=>openModal(it.title)
                                                }["VehicleCarousel[items.map() > <button>.onClick]"],
                                                children: "Request A Free Quote"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/VehicleCarousel.jsx",
                                                lineNumber: 96,
                                                columnNumber: 445
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/VehicleCarousel.jsx",
                                            lineNumber: 96,
                                            columnNumber: 412
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/VehicleCarousel.jsx",
                                    lineNumber: 96,
                                    columnNumber: 77
                                }, this)
                            }, it.title, false, {
                                fileName: "[project]/src/components/VehicleCarousel.jsx",
                                lineNumber: 96,
                                columnNumber: 49
                            }, this)
                    }["VehicleCarousel[items.map()]"])
                }, void 0, false, {
                    fileName: "[project]/src/components/VehicleCarousel.jsx",
                    lineNumber: 84,
                    columnNumber: 54
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VehicleCarousel.jsx",
            lineNumber: 84,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== selectedVehicle || $[7] !== showModal) {
        t5 = showModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$VehicleQuoteModal$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            vehicle: selectedVehicle,
            closeModal: closeModal
        }, void 0, false, {
            fileName: "[project]/src/components/VehicleCarousel.jsx",
            lineNumber: 106,
            columnNumber: 23
        }, this);
        $[6] = selectedVehicle;
        $[7] = showModal;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            id: "vehicles",
            className: "py-16 bg-[#f8fcff]",
            children: [
                t4,
                t5
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/VehicleCarousel.jsx",
            lineNumber: 115,
            columnNumber: 10
        }, this);
        $[9] = t5;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    return t6;
}
_s(VehicleCarousel, "3hujkKXlnwSvqNs+LxDG902fxVQ=");
_c = VehicleCarousel;
var _c;
__turbopack_context__.k.register(_c, "VehicleCarousel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/TourQuote.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>QuoteModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function QuoteModal(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(29);
    if ($[0] !== "acda3d77056fe1b40e2b3b84782cb78b96770a4b67657a37ccb4844bef403073") {
        for(let $i = 0; $i < 29; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "acda3d77056fe1b40e2b3b84782cb78b96770a4b67657a37ccb4844bef403073";
    }
    const { tour, closeModal } = t0;
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [success, setSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = async function submitForm(e) {
            e.preventDefault();
            setLoading(true);
            setSuccess(false);
            const token = await grecaptcha.execute("6LeGmxgsAAAAAL_OhPQVlaPjL-4ioJln-A5uStEQ", {
                action: "submit"
            });
            const formData = new FormData(e.target);
            formData.append("recaptcha", token);
            const res = await fetch("/api/send-tour-quote", {
                method: "POST",
                body: formData
            });
            setLoading(false);
            if (res.ok) {
                setSuccess(true);
                e.target.reset();
            }
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const submitForm = t1;
    let t2;
    if ($[2] !== closeModal) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: closeModal,
            className: "absolute top-3 right-3 text-gray-600 hover:text-black text-xl",
            children: "✕"
        }, void 0, false, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 48,
            columnNumber: 10
        }, this);
        $[2] = closeModal;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-2xl font-semibold mb-4 text-[#1e3a5f]",
            children: "Request A Free Quote"
        }, void 0, false, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 56,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== success) {
        t4 = success && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-green-600 mb-4 font-medium",
            children: "✅ Your quote request has been sent successfully!"
        }, void 0, false, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 63,
            columnNumber: 21
        }, this);
        $[5] = success;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== tour) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "hidden",
            name: "tour",
            value: tour
        }, void 0, false, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[7] = tour;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    let t7;
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Name"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 81,
                    columnNumber: 15
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "name",
                    className: "inputBox",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 81,
                    columnNumber: 58
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Email"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 82,
                    columnNumber: 15
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "email",
                    type: "email",
                    className: "inputBox",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 82,
                    columnNumber: 59
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 82,
            columnNumber: 10
        }, this);
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Phone"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 83,
                    columnNumber: 15
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "phone",
                    type: "tel",
                    className: "inputBox",
                    required: true
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 83,
                    columnNumber: 59
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 83,
            columnNumber: 10
        }, this);
        $[9] = t6;
        $[10] = t7;
        $[11] = t8;
    } else {
        t6 = $[9];
        t7 = $[10];
        t8 = $[11];
    }
    let t9;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-1/2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Adults"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 94,
                    columnNumber: 33
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "adults",
                    type: "number",
                    className: "inputBox"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 94,
                    columnNumber: 78
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 94,
            columnNumber: 10
        }, this);
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    let t10;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-4",
            children: [
                t9,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-1/2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "font-medium",
                            children: "Children"
                        }, void 0, false, {
                            fileName: "[project]/src/components/TourQuote.jsx",
                            lineNumber: 101,
                            columnNumber: 66
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            name: "children",
                            type: "number",
                            className: "inputBox"
                        }, void 0, false, {
                            fileName: "[project]/src/components/TourQuote.jsx",
                            lineNumber: 101,
                            columnNumber: 113
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 101,
                    columnNumber: 43
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 101,
            columnNumber: 11
        }, this);
        $[13] = t10;
    } else {
        t10 = $[13];
    }
    let t11;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-1/2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Arrival"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 108,
                    columnNumber: 34
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "arrival",
                    type: "date",
                    className: "inputBox"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 108,
                    columnNumber: 80
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 108,
            columnNumber: 11
        }, this);
        $[14] = t11;
    } else {
        t11 = $[14];
    }
    let t12;
    let t13;
    let t14;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-4",
            children: [
                t11,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-1/2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "font-medium",
                            children: "Departure"
                        }, void 0, false, {
                            fileName: "[project]/src/components/TourQuote.jsx",
                            lineNumber: 117,
                            columnNumber: 67
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            name: "departure",
                            type: "date",
                            className: "inputBox"
                        }, void 0, false, {
                            fileName: "[project]/src/components/TourQuote.jsx",
                            lineNumber: 117,
                            columnNumber: 115
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 117,
                    columnNumber: 44
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 117,
            columnNumber: 11
        }, this);
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Country"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 118,
                    columnNumber: 16
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    name: "country",
                    className: "inputBox"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 118,
                    columnNumber: 62
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 118,
            columnNumber: 11
        }, this);
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "font-medium",
                    children: "Message"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 119,
                    columnNumber: 16
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                    name: "message",
                    rows: "3",
                    className: "inputBox"
                }, void 0, false, {
                    fileName: "[project]/src/components/TourQuote.jsx",
                    lineNumber: 119,
                    columnNumber: 62
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 119,
            columnNumber: 11
        }, this);
        $[15] = t12;
        $[16] = t13;
        $[17] = t14;
    } else {
        t12 = $[15];
        t13 = $[16];
        t14 = $[17];
    }
    const t15 = `w-full py-3 rounded-xl text-white font-semibold transition ${loading ? "bg-gray-400" : "bg-[#1e3a5f] hover:bg-[#162e4a]"}`;
    const t16 = loading ? "Sending..." : "Send Request";
    let t17;
    if ($[18] !== loading || $[19] !== t15 || $[20] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            disabled: loading,
            className: t15,
            children: t16
        }, void 0, false, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 132,
            columnNumber: 11
        }, this);
        $[18] = loading;
        $[19] = t15;
        $[20] = t16;
        $[21] = t17;
    } else {
        t17 = $[21];
    }
    let t18;
    if ($[22] !== t17 || $[23] !== t5) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
            onSubmit: submitForm,
            className: "space-y-4",
            children: [
                t5,
                t6,
                t7,
                t8,
                t10,
                t12,
                t13,
                t14,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 142,
            columnNumber: 11
        }, this);
        $[22] = t17;
        $[23] = t5;
        $[24] = t18;
    } else {
        t18 = $[24];
    }
    let t19;
    if ($[25] !== t18 || $[26] !== t2 || $[27] !== t4) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white w-full max-w-lg rounded-2xl p-8 shadow-xl relative animate-fadeIn max-h-[100vh] overflow-y-auto",
                children: [
                    t2,
                    t3,
                    t4,
                    t18
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/TourQuote.jsx",
                lineNumber: 151,
                columnNumber: 109
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/TourQuote.jsx",
            lineNumber: 151,
            columnNumber: 11
        }, this);
        $[25] = t18;
        $[26] = t2;
        $[27] = t4;
        $[28] = t19;
    } else {
        t19 = $[28];
    }
    return t19;
}
_s(QuoteModal, "YqRSekwUJue4kKje6jZ35rjMwKc=");
_c = QuoteModal;
var _c;
__turbopack_context__.k.register(_c, "QuoteModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/itinerary/tourData.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "tours",
    ()=>tours
]);
const tours = [
    {
        slug: "14-days-diversity-tour",
        title: "14 Days Diversity Tour",
        days: "14 Day / 13 Night",
        pax: "Any size",
        images: [
            "/17114457010.jpg",
            "/17115409501.jpg",
            "/17115409502.jpg",
            "/17115409503.jpg"
        ],
        desc: `Embark on a mesmerizing 14-day journey through the diverse landscapes and rich cultural tapestry of Sri Lanka. Starting in Negombo, the coastal town sets the tone for the adventure, blending native hospitality and vibrant local culture. The journey unfolds with a visit to Anuradhapura, an ancient city steeped in heritage, housing sacred sites like the Bodhi Tree and Ruwanwelisaya. As you ascend the iconic Sigiriya Rock Fortress and explore the ancient marvels of Polonnaruwa, the tour delves deep into the island's cultural roots. Kandy, the cultural capital, invites you to witness the Temple of the Tooth Relic and immerse yourself in the lush Royal Botanical Gardens.

The exploration extends to the cool climes of Nuwara Eliya, where tea plantations and the breathtaking Horton Plains National Park await. Ella, with its scenic waterfalls and picturesque landscapes, offers an enchanting respite before venturing into the untamed beauty of Yala National Park. Safaris unveil Sri Lanka's diverse wildlife, from elusive leopards to majestic elephants. Throughout this unforgettable journey, a comfortable car and experienced driver ensure seamless travel.

From the tranquility of tea plantations to the thrill of wildlife adventures, this tour promises a perfect blend of cultural immersion and exploration, creating lasting memories in the heart of the Indian Ocean.`,
        itinerary: [
            {
                day: "Day 1 - Arrival in Negombo",
                content: `
• Arrive in Negombo and check into your hotel.
• Relax and recover after your journey.
• Explore Negombo Beach and enjoy the vibrant local atmosphere.
    `
            },
            {
                day: "Day 2-3 - Anuradhapura",
                content: `
• Drive to Anuradhapura (approx. 4–5 hours).
• Explore the sacred Jaya Sri Maha Bodhi.
• Visit Ruwanwelisaya and Thuparamaya.
• Discover UNESCO World Heritage archaeological sites.
• Spend two nights exploring the ancient capital.
    `
            },
            {
                day: "Day 4-5 - Sigiriya and Dambulla",
                content: `
• Drive to Sigiriya (approx. 2–3 hours).
• Climb Sigiriya Rock Fortress and see the ancient frescoes.
• Visit the Dambulla Cave Temple.
• Explore nearby cultural villages and viewpoints.
• Spend two nights in Sigiriya/Dambulla.
    `
            },
            {
                day: "Day 6-7 - Kandy",
                content: `
• Drive to Kandy (approx. 2–3 hours).
• Visit the Temple of the Tooth Relic.
• Explore the Royal Botanical Gardens.
• Enjoy a traditional Kandyan cultural dance show.
• Visit Kandy Garrison Cemetery and Udawattakele Forest Reserve.
• Spend two nights in Kandy.
    `
            },
            {
                day: "Day 8-9 - Nuwara Eliya",
                content: `
• Drive to Nuwara Eliya (approx. 2–3 hours).
• Visit a tea plantation and witness tea-making.
• Explore scenic highland landscapes.
• Enjoy the cool climate of “Little England.”
• Visit Horton Plains National Park and World's End.
• Spend two nights in Nuwara Eliya.
    `
            },
            {
                day: "Day 10-11 - Ella",
                content: `
• Drive to Ella (approx. 2 hours).
• Visit the famous Nine Arch Bridge.
• Hike Little Adam's Peak.
• Enjoy a scenic train ride with stunning mountain views.
• Explore waterfalls and lush greenery.
• Spend two nights in Ella.
    `
            },
            {
                day: "Day 12-13 - Yala National Park",
                content: `
• Drive to Yala National Park (approx. 2–3 hours).
• Embark on wildlife safaris.
• Spot leopards, elephants, sloth bears, and bird species.
• Stay in a safari lodge close to nature.
• Spend two nights enjoying Yala’s wilderness.
    `
            },
            {
                day: "Day 14 - Departure from Colombo",
                content: `
• Drive back to Colombo (approx. 4–5 hours).
• Explore Galle Face Green or enjoy last-minute shopping.
• Transfer to Bandaranaike International Airport for your departure.
    `
            }
        ],
        includes: [
            {
                icon: "⛽",
                title: "Free Fuel",
                desc: "Fuel to keep your journey rolling"
            },
            {
                icon: "🏨",
                title: "Accommodation",
                desc: "Comfortable hotels included"
            },
            {
                icon: "👨‍✈️",
                title: "Experienced Guide",
                desc: "Experienced and trained guide"
            },
            {
                icon: "🅿️",
                title: "Parking Fees",
                desc: "Parking fees for worry-free stops."
            }
        ]
    },
    {
        slug: "4-days-flagship-itinerary",
        title: "4 Days flagship Itinerary",
        days: "4 Day / 3 Night",
        pax: "Any size",
        images: [
            "/17114469141.jpg",
            "/17299371410.jpeg",
            "/17299380390.JPG",
            "/17299380391.jpg"
        ],
        desc: `Embark on an exhilarating 4-day adventure through the heart of Sri Lanka with our meticulously curated itinerary. Our tailored itineraries offer the perfect blend of exploration and relaxation,catering to solo travelers, couples seeking romantic getaways, and families on the lookout for exciting excursions. With the convenience of a skilled driver, your journey becomes seamless,allowing you to focus on the breathtaking landscapes and rich cultural experiences. Immerse yourself in the romantic allure of Kandy, surrounded by historic temples and verdant tea plantations. For those seeking flexibility, we recommend the option to rent a car, providing the freedom to discover hidden gems along the way. Indulge in the authentic flavors of Ceylon tea,enhancing your adventure with every sip. Join us on this unforgettable expedition, where each moment offers a unique blend of adventure and tranquility amidst the enchanting landscapes of Sri Lanka.`,
        itinerary: [
            {
                day: "Day 1 - Arrival in Colombo",
                content: `• Arrive at Bandaranaike International Airport in Colombo.
• Transfer to your hotel and check-in.
• Spend the day relaxing to recover from the journey.
• In the evening, explore local markets or enjoy a leisurely stroll near your accommodation.
• Overnight stay in Colombo.`
            },
            {
                day: "Day 2 - Colombo to Kandy",
                content: `• Morning departure to Kandy (approximately 3–4 hours by car or train).
• Visit the Temple of the Tooth Relic, a significant Buddhist shrine.
• Explore the Peradeniya Royal Botanic Gardens.
• Stroll around Kandy Lake.
• Optional: Attend a traditional Kandyan dance performance in the evening.
• Overnight stay in Kandy.`
            },
            {
                day: "Day 3 - Kandy to Dambulla/Sigiriya",
                content: `• Morning drive to Dambulla/Sigiriya (approximately 2–3 hours).
• Visit the Dambulla Cave Temple or climb Sigiriya Rock Fortress.
• Explore the ancient city of Polonnaruwa (if time allows).
• Overnight stay in Dambulla/Sigiriya.`
            },
            {
                day: "Day 4 - Return to Colombo and Departure",
                content: `• Morning return to Colombo (approximately 4–5 hours by car or train).
• Explore Colombo's highlights such as Galle Face Green, Independence Square, and Pettah Market.
• Depending on your departure time, enjoy last-minute shopping.
• Transfer to Bandaranaike International Airport for departure.`
            }
        ],
        includes: [
            {
                icon: "⛽",
                title: "Free Fuel",
                desc: "Fuel to keep your journey rolling"
            },
            {
                icon: "🏨",
                title: "Accommodation",
                desc: "Comfortable hotels included"
            },
            {
                icon: "👨‍✈️",
                title: "Experienced Guide",
                desc: "Experienced and trained guide"
            },
            {
                icon: "🅿️",
                title: "Parking Fees",
                desc: "Parking fees for worry-free stops."
            }
        ]
    },
    {
        slug: "12-days-cultural-heritage-tour",
        title: "12 Days Cultural & Heritage Tour",
        days: "12 Day / 11 Night",
        pax: "Any size",
        images: [
            "/17205182150.jpg",
            "/17205182151.jpg",
            "/17299379120.jpg",
            "/17299379131.jpg",
            "/17299379132.jpg"
        ],
        desc: `Embark on a 12-day odyssey through the cultural and heritage wonders of Sri Lanka, commencing in the vibrant coastal town of Negombo. As the journey unfolds, the ancient city of Anuradhapura beckons with its sacred Bodhi Tree and majestic ruins, showcasing the country's rich heritage. The adventure continues with the iconic Sigiriya Rock Fortress, a testament to ancient engineering marvels, complemented by the cultural splendors of Dambulla Cave Temple. In Kandy, the cultural capital, the Temple of the Tooth Relic captivates with its spiritual aura, while the lush landscapes of Nuwara Eliya offer a traditional tea plantation experience. The exploration extends to Galle, a coastal gem adorned with the UNESCO-listed Galle Fort, inviting visitors to wander through its cobbled streets steeped in history. Throughout this immersive tour, a comfortable car and driver facilitate seamless travel, ensuring you can fully indulge in the warmth of Sri Lankan hospitality and uncover the nation's rich cultural tapestry. From the tranquil tea estates to the bustling heritage sites, this itinerary promises an enchanting blend of exploration and relaxation, providing an ideal escape for those seeking traditional getaways infused with native charm`,
        itinerary: [
            {
                day: "Day 1 - Arrival in Negombo",
                content: `
• Arrive in Negombo, check into your hotel, and relax after your journey.
• Explore Negombo Beach and the local fish market.
    `
            },
            {
                day: "Day 2-3 - Anuradhapura",
                content: `
• Drive to Anuradhapura (approx. 4–5 hours).
• Spend two nights exploring the ancient city's archaeological and historical sites,
  including the sacred Bodhi Tree, Ruwanwelisaya, and Thuparamaya.
    `
            },
            {
                day: "Day 4-5 - Sigiriya and Dambulla",
                content: `
• Drive to Sigiriya (approx. 1–2 hours).
• Climb the iconic Sigiriya Rock Fortress.
• Visit the Dambulla Cave Temple.
• Stay for two nights to explore more sites like Polonnaruwa, another ancient city.
    `
            },
            {
                day: "Day 6-7 - Kandy",
                content: `
• Drive to Kandy (approx. 2–3 hours).
• Visit the Temple of the Tooth Relic and explore the Royal Botanical Gardens.
• Enjoy a cultural dance performance.
• Explore more attractions, including the Kandy Garrison Cemetery 
  and the Udawattakele Forest Reserve.
    `
            },
            {
                day: "Day 8-9 - Nuwara Eliya",
                content: `
• Drive to Nuwara Eliya (approx. 2–3 hours).
• Visit a tea plantation and learn about the tea-making process.
• Explore the beautiful landscapes and enjoy the cool climate.
• Spend two nights and visit Horton Plains National Park and World's End.
    `
            },
            {
                day: "Day 10-11 - Galle",
                content: `
• Drive to Galle (approx. 5–6 hours).
• Explore Galle Fort, a UNESCO World Heritage Site.
• Visit the Galle Maritime Museum and stroll through the historic narrow streets.
• Spend two nights relaxing on Unawatuna Beach and exploring nearby attractions.
    `
            },
            {
                day: "Day 12 - Departure from Colombo",
                content: `
• Drive to Colombo (approx. 2–3 hours).
• Briefly explore Colombo — Independence Square or Gangaramaya Temple.
• Depart from Colombo for your return flight.
    `
            }
        ],
        includes: [
            {
                icon: "⛽",
                title: "Free Fuel",
                desc: "Fuel to keep your journey rolling"
            },
            {
                icon: "🏨",
                title: "Accommodation",
                desc: "Comfortable hotels included"
            },
            {
                icon: "👨‍✈️",
                title: "Experienced Guide",
                desc: "Experienced and trained guide"
            },
            {
                icon: "🅿️",
                title: "Parking Fees",
                desc: "Parking fees for worry-free stops."
            }
        ]
    },
    {
        slug: "10-days-southern-beach-tour",
        title: "10 Days Southern Beach Tour",
        days: "10 Day / 9 Night",
        pax: "Any size",
        images: [
            "/17115433630.jpeg",
            "/17115433631.jpg",
            "/17115433632.jpeg",
            "/17115433633.jpeg"
        ],
        desc: `Embark on a 10-day coastal odyssey along the sun-kissed shores of southern Sri Lanka, commencing in the vibrant coastal town of Negombo. Your journey unfolds with two idyllic nights in Bentota, a beach haven known for its golden sands and thrilling water activities. Cruise the Bentota River amidst swaying coconut palms, immersing yourself in the tropical landscape. Galle, a UNESCO World Heritage Site, beckons next, captivating travelers with its colonial charm within the fortified Galle Fort. As you bask in the historical ambiance, the maritime museum and cobblestone streets unfold tales of a bygone era. Mirissa, a beach enthusiast's delight, welcomes you next with two nights of oceanic wonders. Dive into the adventure with a whale-watching tour, an unforgettable encounter with majestic marine life. Tangalle, a coastal gem, invites you to unwind on Hiriketiya Beach, where tranquil turquoise waters meet pristine sands.

Your journey concludes in Colombo, but not before experiencing the untouched beauty of Tangalle's Goyambokka Beach. The relaxing atmosphere, coupled with the rhythmic sounds of the ocean, creates a haven for beach lovers. Throughout this coastal sojourn, a comfortable car and driver ensure seamless travel, allowing you to relish the cultural tapestry, adventure, and warm hospitality of Sri Lanka. From cultural immersions to beachside sunbathing, this itinerary promises a perfect blend of relaxation and exploration, making it an ideal escape for those seeking coastal getaways enriched with culture and adventure.`,
        itinerary: [
            {
                day: "Day 1 - Arrival in Negombo",
                content: `
• Arrive in Negombo, check into your hotel, and unwind.
• Explore Negombo Beach and its vibrant local atmosphere.
    `
            },
            {
                day: "Day 2-3 - Bentota",
                content: `
• Drive to Bentota (approx. 2–3 hours).
• Spend two nights exploring Bentota's beautiful beaches and engaging in water activities.
• Visit the Brief Garden and the Bentota Turtle Hatchery.
    `
            },
            {
                day: "Day 4-5 - Galle",
                content: `
• Drive to Galle (approx. 1–2 hours).
• Explore Galle Fort, a UNESCO World Heritage Site, over two days.
• Wander through the Dutch Reformed Church and the charming streets of the fort.
• Visit the Galle Maritime Museum.
    `
            },
            {
                day: "Day 6-7 - Mirissa",
                content: `
• Head to Mirissa (approx. 1–2 hours).
• Relax on Mirissa Beach and enjoy its laid-back atmosphere.
• Take a whale-watching tour (seasonal).
• Explore Coconut Tree Hill for panoramic views.
    `
            },
            {
                day: "Day 8-9 - Tangalle",
                content: `
• Drive to Tangalle (approx. 2–3 hours).
• Spend two nights exploring Hiriketiya Beach and Goyambokka Beach.
• Relax on the pristine sandy shores and enjoy the tranquil surroundings.
    `
            }
        ],
        includes: [
            {
                icon: "⛽",
                title: "Free Fuel",
                desc: "Fuel to keep your journey rolling"
            },
            {
                icon: "🏨",
                title: "Accommodation",
                desc: "Comfortable hotels included"
            },
            {
                icon: "👨‍✈️",
                title: "Experienced Guide",
                desc: "Experienced and trained guide"
            },
            {
                icon: "🅿️",
                title: "Parking Fees",
                desc: "Parking fees for worry-free stops."
            }
        ]
    },
    {
        slug: "7-days-grand-tour",
        title: "7 Days’ Grand tour.",
        days: "7 Day / 6 Night",
        pax: "Any size",
        images: [
            "/17115440022.jpg",
            "/17299381110.jpg",
            "/17299381141.jpeg",
            "/17299387620.jpg"
        ],
        desc: `Embark on a mesmerizing 7-day journey through the diverse landscapes of Sri Lanka, starting in the vibrant coastal town of Negombo. Kick off your adventure with a relaxing day at Negombo Beach, known for its golden sands and bustling fish market. The next destination is the cultural heart of the island – Kandy. Immerse yourself in the rich cultural tapestry with a visit to the Temple of the Tooth Relic and witness the vibrant Kandyan cultural dance. The journey continues on a scenic train ride to Ella, a charming hill station surrounded by lush tea plantations. Explore the iconic Nine Arch Bridge and savor the tranquility atop Little Adam's Peak.

Continue the exploration with a thrilling safari in Yala National Park, home to elusive leopards and diverse wildlife. As you journey to the coastal haven of Mirissa, relish the hospitality of Sri Lanka's coastal communities. A whale-watching tour offers an exciting marine adventure before heading to the historic Galle Fort. Wander through its cobbled streets steeped in culture and history. The final leg takes you to Colombo, where you can discover the city's unique blend of modernity and tradition, exemplified by the Gangaramaya Temple and Independence Square. Throughout your tour, a comfortable car and driver ensure seamless travel, allowing you to indulge in the beauty of each destination and enjoy a perfect blend of relaxation and adventure in this exotic getaway`,
        itinerary: [
            {
                day: "Day 1 - Arrival in Negombo",
                content: `
• Arrive in Negombo, check into your hotel, and rest after your journey.
• Explore Negombo Beach and the local fish market.
• Enjoy a relaxing evening by the beach.
    `
            },
            {
                day: "Day 2 - Negombo to Kandy",
                content: `
• Drive to Kandy (approx. 3–4 hours).
• Visit the Temple of the Tooth Relic.
• Explore the Royal Botanical Gardens.
• Enjoy a traditional Kandyan cultural dance performance in the evening.
    `
            },
            {
                day: "Day 3 - Kandy to Ella",
                content: `
• Take a scenic train ride from Kandy to Ella (approx. 6 hours).
• Visit the Nine Arch Bridge and Little Adam's Peak in Ella.
• Explore Ella town and enjoy the laid-back atmosphere.
    `
            },
            {
                day: "Day 4 - Ella to Yala National Park",
                content: `
• Drive to Yala National Park (approx. 2–3 hours).
• Embark on an afternoon safari in Yala National Park, famous for its leopard population and diverse wildlife.
• Spend the night at a hotel near the park.
    `
            },
            {
                day: "Day 5 - Yala to Mirissa",
                content: `
• Take a morning safari in Yala (if you didn't do one the previous afternoon).
• Drive to Mirissa (approx. 3–4 hours).
• Relax on Mirissa Beach and enjoy the sunset.
• Explore the vibrant beachside nightlife.
    `
            },
            {
                day: "Day 6 - Mirissa to Galle",
                content: `
• Visit the famous Mirissa Fishermen's Harbour and enjoy a whale-watching tour (seasonal).
• Drive to Galle (approx. 1–2 hours).
• Explore Galle Fort, a UNESCO World Heritage Site, in the afternoon.
• Wander through the charming streets of Galle and experience its unique blend of history and modernity.
    `
            },
            {
                day: "Day 7 - Departure from Colombo",
                content: `
• Drive to Colombo (approx. 2–3 hours).
• If time permits, explore the city, visit the Gangaramaya Temple, and stroll through Independence Square.
• Depart from Colombo.
    `
            }
        ],
        includes: [
            {
                icon: "⛽",
                title: "Free Fuel",
                desc: "Fuel to keep your journey rolling"
            },
            {
                icon: "🏨",
                title: "Accommodation",
                desc: "Comfortable hotels included"
            },
            {
                icon: "👨‍✈️",
                title: "Experienced Guide",
                desc: "Experienced and trained guide"
            },
            {
                icon: "🅿️",
                title: "Parking Fees",
                desc: "Parking fees for worry-free stops."
            }
        ]
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ItineraryGrid.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ItineraryGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/swiper/swiper-react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__ = __turbopack_context__.i("[project]/node_modules/swiper/modules/pagination.mjs [app-client] (ecmascript) <export default as Pagination>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$TourQuote$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/TourQuote.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$itinerary$2f$tourData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/itinerary/tourData.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
function ItineraryGrid() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10);
    if ($[0] !== "6fbded83fc44b9aea6994e5998afb5504b446094b7524ac842fbf73e3b7171cb") {
        for(let $i = 0; $i < 10; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6fbded83fc44b9aea6994e5998afb5504b446094b7524ac842fbf73e3b7171cb";
    }
    const [showModal, setShowModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedTour, setSelectedTour] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = ({
            "ItineraryGrid[openModal]": (tourName)=>{
                setSelectedTour(tourName);
                setShowModal(true);
            }
        })["ItineraryGrid[openModal]"];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const openModal = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "ItineraryGrid[closeModal]": ()=>setShowModal(false)
        })["ItineraryGrid[closeModal]"];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const closeModal = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-3xl font-bold mb-8 text-gray-800 mt-6 text-center md:text-left",
            children: "Our Popular Itineraries"
        }, void 0, false, {
            fileName: "[project]/src/components/ItineraryGrid.jsx",
            lineNumber: 74,
            columnNumber: 10
        }, this);
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4 sm:px-6",
            children: [
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
                    children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$itinerary$2f$tourData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tours"].map({
                        "ItineraryGrid[tours.map()]": (t, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                                className: "tour-card",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Swiper"], {
                                        modules: [
                                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$modules$2f$pagination$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pagination$3e$__["Pagination"]
                                        ],
                                        pagination: {
                                            clickable: true
                                        },
                                        className: "tour-img-slider",
                                        children: t.images.map({
                                            "ItineraryGrid[tours.map() > t.images.map()]": (img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$swiper$2f$swiper$2d$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SwiperSlide"], {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "relative h-60 sm:h-64 rounded-xl overflow-hidden",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            src: img,
                                                            alt: t.title,
                                                            fill: true,
                                                            className: "object-cover"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                            lineNumber: 85,
                                                            columnNumber: 167
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                        lineNumber: 85,
                                                        columnNumber: 101
                                                    }, this)
                                                }, idx, false, {
                                                    fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                    lineNumber: 85,
                                                    columnNumber: 78
                                                }, this)
                                        }["ItineraryGrid[tours.map() > t.images.map()]"])
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                        lineNumber: 82,
                                        columnNumber: 90
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between mt-3 text-gray-600 text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-lg",
                                                        children: "👥"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                        lineNumber: 86,
                                                        columnNumber: 193
                                                    }, this),
                                                    " ",
                                                    t.pax
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                lineNumber: 86,
                                                columnNumber: 152
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-lg",
                                                        children: "📅"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                        lineNumber: 86,
                                                        columnNumber: 283
                                                    }, this),
                                                    " ",
                                                    t.days
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ItineraryGrid.jsx",
                                                lineNumber: 86,
                                                columnNumber: 242
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                        lineNumber: 86,
                                        columnNumber: 74
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "mt-4 text-xl font-semibold text-gray-800",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: `/itinerary/itinerary-inner/${t.slug}`,
                                            className: "hover:text-blue-600 transition",
                                            children: t.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ItineraryGrid.jsx",
                                            lineNumber: 86,
                                            columnNumber: 396
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                        lineNumber: 86,
                                        columnNumber: 339
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-gray-600 mt-2 line-clamp-3",
                                        children: t.desc
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                        lineNumber: 86,
                                        columnNumber: 512
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "btn-yellow mt-5 w-full sm:w-auto",
                                        onClick: {
                                            "ItineraryGrid[tours.map() > <button>.onClick]": ()=>openModal(t.title)
                                        }["ItineraryGrid[tours.map() > <button>.onClick]"],
                                        children: "Request A Free Quote"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ItineraryGrid.jsx",
                                        lineNumber: 86,
                                        columnNumber: 579
                                    }, this)
                                ]
                            }, i, true, {
                                fileName: "[project]/src/components/ItineraryGrid.jsx",
                                lineNumber: 82,
                                columnNumber: 51
                            }, this)
                    }["ItineraryGrid[tours.map()]"])
                }, void 0, false, {
                    fileName: "[project]/src/components/ItineraryGrid.jsx",
                    lineNumber: 81,
                    columnNumber: 62
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ItineraryGrid.jsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== selectedTour || $[6] !== showModal) {
        t4 = showModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$TourQuote$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            tour: selectedTour,
            closeModal: closeModal
        }, void 0, false, {
            fileName: "[project]/src/components/ItineraryGrid.jsx",
            lineNumber: 96,
            columnNumber: 23
        }, this);
        $[5] = selectedTour;
        $[6] = showModal;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-14 bg-slate-50",
            children: [
                t3,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ItineraryGrid.jsx",
            lineNumber: 105,
            columnNumber: 10
        }, this);
        $[8] = t4;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    return t5;
}
_s(ItineraryGrid, "zAU4OnEoohvET4OMcuEwF+vrdjQ=");
_c = ItineraryGrid;
var _c;
__turbopack_context__.k.register(_c, "ItineraryGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_1c1ddd2f._.js.map