(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_8b5ad68c._.js",
  "static/chunks/src_1c1ddd2f._.js",
  "static/chunks/src_components_2db32c5a._.css"
],
    source: "dynamic"
});
