(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_db2b978a._.css",
  "static/chunks/_2ac2dbec._.js"
],
    source: "dynamic"
});
