(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_8c7dabb7._.css",
  "static/chunks/_0b580c43._.js"
],
    source: "dynamic"
});
