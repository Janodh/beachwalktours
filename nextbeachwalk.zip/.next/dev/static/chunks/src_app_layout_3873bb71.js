(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_8c7dabb7._.css",
  "static/chunks/_30f3d54d._.js"
],
    source: "dynamic"
});
