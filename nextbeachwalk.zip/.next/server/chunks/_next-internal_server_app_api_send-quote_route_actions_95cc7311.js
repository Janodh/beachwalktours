module.exports=[28306,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_send-quote_route_actions_95cc7311.js.map