module.exports=[41640,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_vehicle-rent_page_actions_1001320f.js.map