var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-tour-quote/route.js")
R.c("server/chunks/[root-of-the-server]__c78a51f9._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__efafb54b._.js")
R.c("server/chunks/_next-internal_server_app_api_send-tour-quote_route_actions_4d7914f7.js")
R.m(27212)
module.exports=R.m(27212).exports
